#version 120
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - composite2.vsh
Render: Antialiasing

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define COMPOSITE2_SHADER

#include "/common/composite2_vertex.glsl"
