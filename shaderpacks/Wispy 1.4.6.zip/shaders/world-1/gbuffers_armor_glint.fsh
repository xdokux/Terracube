#version 120
#define DIMENSION_NETHER

#include "/program/gbuffers_armor_glint.fsh"
