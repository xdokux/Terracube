uniform float viewWidth;
uniform float viewHeight;

out vec2 texcoord;
out vec4 glcolor;

void main() {
	gl_Position = ftransform();
	glcolor = gl_Color;
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}