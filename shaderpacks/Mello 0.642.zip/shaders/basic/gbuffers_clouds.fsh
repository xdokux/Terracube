void main() {
	discard;
}