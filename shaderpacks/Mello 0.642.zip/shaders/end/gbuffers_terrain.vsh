#version 330 compatibility

#include "/basic/gbuffers_terrain.vsh"