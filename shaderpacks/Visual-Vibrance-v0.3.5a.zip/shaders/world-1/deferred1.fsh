#include "/lib/version.glsl"

#define fsh
#define WORLD_THE_NETHER

#include "/program/deferred1.glsl"
