#version 400 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite1.vsh"
