#version 460 compatibility
#define DIMENSION_END

#define GBUFFERS_TEXTURED
#include "/program/gbuffers_basic.vsh"
