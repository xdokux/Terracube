#version 460 compatibility
#define DIMENSION_NETHER

#include "/program/composite7.vsh"