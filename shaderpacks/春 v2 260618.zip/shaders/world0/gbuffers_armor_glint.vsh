#version 450 compatibility  

#define VSH
#define GBF

#include "/program/gbuffers_armor_glint.glsl"