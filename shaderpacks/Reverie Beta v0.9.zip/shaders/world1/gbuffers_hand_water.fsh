#version 460 compatibility
#define DIMENSION_END

#include "/program/gbuffers_hand_water.fsh"
