#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/prepare_c.csh"