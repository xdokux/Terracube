#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite51.vsh"