#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/gbuffers_weather.vsh"
