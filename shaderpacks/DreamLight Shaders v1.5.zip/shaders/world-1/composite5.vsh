#version 120
#define DIMENSION_NETHER

#include "/program/composite5.vsh"
