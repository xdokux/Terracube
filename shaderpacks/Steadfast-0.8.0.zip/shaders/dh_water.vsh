// Steadfast is a fast and high-quality graphical overhaul for Minecraft (JE)
// Copyright (C) 2026 coderbot
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

#version 150 compatibility
#define NEVER_RECEIVES_SHADOWS
#define NORMALS_ARE_IN_WORLD_SPACE
#define NO_GTEXTURE
#define HAS_DH_MATERIAL_ID
// Whether to enable fancy translucent effects. When disabled, translucents are
// rendered with the same shading as solids.
#define FANCY_TRANSLUCENTS
#ifdef FANCY_TRANSLUCENTS
	#define TRANSLUCENT
	// Whether to lower distant water faces to the same height as vanilla water
	#define LOWER_DISTANT_WATER_HEIGHT
#endif
#include "/program/world/lit.vsh"
