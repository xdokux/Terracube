#version 400 compatibility
#define DIMENSION_GENERIC

#include "/program/gbuffers_armor_glint.vsh"
