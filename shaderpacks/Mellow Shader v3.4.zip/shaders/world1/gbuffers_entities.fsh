#version 400 compatibility
#define DIMENSION_END

#include "/program/gbuffers_entities.fsh"
