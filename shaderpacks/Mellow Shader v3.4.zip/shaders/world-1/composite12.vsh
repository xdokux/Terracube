#version 400 compatibility
#define DIMENSION_NETHER

#include "/program/composite12.vsh"