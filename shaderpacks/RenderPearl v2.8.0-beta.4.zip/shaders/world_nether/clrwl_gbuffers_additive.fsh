#define NETHER
#include "/world_default/clrwl_gbuffers_additive.fsh"
